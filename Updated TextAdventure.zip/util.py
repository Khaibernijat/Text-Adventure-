import time 
def dagRoomGraphics():
    
    print( """\n    /\\""")
    time.sleep(.2)
    print( """   |   |""")
    time.sleep(.2)
    print( """   |   |""")
    time.sleep(.2)
    print( """   |   |""")
    time.sleep(.2)
    print( """   |   |""")
    time.sleep(.2)
    print( """___|   |___""")
    time.sleep(.2)
    print( """|____   ____|""")
    time.sleep(.2)
    print( """   |   |""")
    time.sleep(.2)
    print( """   _____""")

